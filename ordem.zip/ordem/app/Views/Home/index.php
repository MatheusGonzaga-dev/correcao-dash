<?= $this->extend('Layout/principal') ?>

<?= $this->section('titulo') ?>
  <?php echo $titulo; ?>
<?= $this->endSection() ?>

<?= $this->section('estilos') ?>
  
<?= $this->endSection() ?>


<?= $this->section('conteudo') ?>
  
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
  
<?= $this->endSection() ?>