<?php

namespace App\Controllers;

use App\Controllers\BaseController;



class Login extends BaseController
{
    public function novo()
    {
        
        $data = [
            'titulo' => 'Realize o login',
        ];

        return view('Login/novo', $data);


    }


    public function criar(){

            if (!$this->request->isAJAX()) {
                return redirect()->back();
            }

    
            // Envio o hash do token do form
            $retorno['token'] = csrf_hash();
    
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');
    
            // Recuperando a instância do serviço autenticacao
            $autenticacao = service('autenticacao');
    
    
            if($autenticacao->login($email, $password) === false){
    
                // Credenciais inválidas
    
                $retorno['erro'] = 'Por favor verifique os abaixo e tente novamente';
                $retorno['erros_model'] = ['credenciais' => 'Não encontramos suas credenciais de acesso'];
                return $this->response->setJSON($retorno);
    
            }

        //credenciais validas
        exit("validado");

    }
}
